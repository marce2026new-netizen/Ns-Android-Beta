# CryptoBot Demo Android

Este proyecto es una app Android de demostración que envuelve una interfaz local adaptable a pantallas de móvil. No se conecta a Bitso y no realiza operaciones.

## Cómo generar el APK
1. Instala Android Studio en Windows desde https://developer.android.com/studio
2. Descomprime este ZIP.
3. En Android Studio selecciona **Open** y elige la carpeta `CryptoBotAndroid`.
4. Espera a que termine la sincronización de Gradle e instala el Android SDK si lo solicita.
5. Menú **Build → Build APK(s)**.
6. El APK de depuración suele quedar en `app/build/outputs/apk/debug/app-debug.apk`.
7. Pasa el APK a tu teléfono e instálalo. Android puede pedir autorización para instalar apps de esa fuente.

## Seguridad
- Solo muestra datos inventados.
- No solicita permisos de Internet ni acceso a almacenamiento.
- No introduzcas claves API reales.
- No es la plataforma de trading completa.
